
unsigned int factorielle  ( int n );
unsigned int sommeEntiers ( int n );

double calcMoyenne( int taille, double tab[] );