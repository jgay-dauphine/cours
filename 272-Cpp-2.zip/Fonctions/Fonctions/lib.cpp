// Lib.cpp : fichier biblioth�que de fonctions

#include "stdafx.h"
#include "lib.h"

double calcMoyenne( int taille, double tab[] )
{
	double somme = 0;
	
	for( int i = 0; i < taille; ++i )
	{
		somme = somme + tab[i];
	}

	return (somme / taille);
}

unsigned int factorielle( int n )
{
	int i = 2;
	unsigned int s = 1;

	for( ; i <= n; ++i )	{
		s *= i;
	}

	return s;
}

unsigned int sommeEntiers( int n )
{
	unsigned int somme=0;

	/* Mauvaise solution � base de for
	for( int i = 1; i <= n; ++i )
	{
		somme = somme + i;
	}
	*/

	somme = n * (n + 1) / 2;
	
	return somme;
}
