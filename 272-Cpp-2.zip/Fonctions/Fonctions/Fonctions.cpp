// Fonctions.cpp�: d�finit le point d'entr�e pour l'application console.

#include "stdafx.h"
#include <iostream>

using namespace std;

#include "lib.h"

int _tmain(int argc, _TCHAR* argv[])
{
	const int tailleTabFact = 4, tailleTabSomInt = 5;
	const int tailleTabMoyenne = 8;

	double tabMoyenne[tailleTabMoyenne] = { 
		17, 12, 4, 19.5, 13, 8, 12, 13 
	};

	int tabFact   [tailleTabFact]   = {
		0, 1, 5, 10
	};

	int tabSomInt [tailleTabSomInt] = {
		0, 1, 5, 20, 50
	};

	for( int i = 0; i < tailleTabFact; ++i )
	{
		cout << "Factorielle(" << tabFact[i] << ") = " << factorielle(tabFact[i]) << endl;
	}

	for( int i = 0; i < tailleTabSomInt; ++i )
	{
		cout << "Somme des " << tabFact[i] << " premiers entiers = " << sommeEntiers(tabFact[i]) << endl;
	}

	cout << "La moyenne des notes est " << calcMoyenne(tailleTabMoyenne, tabMoyenne) << endl;
	
	system("PAUSE");

	return 0;
}